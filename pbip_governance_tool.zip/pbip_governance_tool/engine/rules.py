"""
Rule definitions.

Rule 1  slicer_header_disabled   - every SLICER's "Header icons" (Format pane
                                    General > Header icons > master toggle)
                                    must be OFF.
Rule 2  visual_header_focus_only - every NON-slicer visual must have its
                                    header icons ON, but with only the
                                    "Focus mode" icon enabled; every other
                                    icon (Options, Filter, Pin, Drill, See
                                    data) disabled.
Rule 3  sort_ascending           - any visual that already has an explicit
                                    sort configured must sort Ascending
                                    (visuals with no sort at all are left
                                    alone / reported as not applicable).
Rule 4  color_palette_compliance - see check_visual_colors / check_theme_colors.
Rule 5  export_disabled          - report.json's settings.exportDataMode must
                                    not allow full/underlying data export -
                                    "None" (fully disabled) or a
                                    summarized-only value are both compliant.
Rule 6  filters_locked_hidden    - any filter (report-level or per-visual)
                                    that's actively applied (has a `filter`
                                    condition, i.e. isn't just an empty card
                                    sitting in the panel) must be both locked
                                    and hidden in view mode.
Rule 7  legend_bold              - a visual's legend must not have bold
                                    explicitly turned off (objects.legend[].
                                    properties.bold === false).
Rule 8  data_source_review       - detection-only: surfaces every data
                                    source connection found in the report's
                                    paired .SemanticModel (Power Query M
                                    `Source = ...` steps in its .tmdl files)
                                    so a human can review where the data
                                    actually comes from. There's no safe
                                    automatic "fix" for a data connection,
                                    so these findings are never fixable.

Notes / assumptions (confirmed with the user, and verified against a real
visual.json written by Power BI Desktop 2.12.0 schema):
  - "Header icons" for slicers = the standard Format-pane header section
    (visualHeader / vcObjects.visualHeader), not the slicer's separate
    clear-selection control. Ground truth: disabling it writes only
    `"show": false` inside visualHeader.properties - nothing else.
  - "Enabled only on focus mode" has no literal native PBI equivalent, and
    critically: Power BI Desktop does NOT write a dedicated property for the
    Focus mode icon at all, and does not write "show": true either - both
    are the default state, and Power BI only persists properties that
    differ from default. So the fix never touches "show" (unless it was
    explicitly turned off) and never invents a "focus mode" property; it
    only explicitly disables every *other* action icon. Verified property
    names for those other icons (schema 2.12.0): showOptionsMenu,
    showFilterRestatementButton, showPinButton, showSeeDataLayoutToggleButton,
    showDrillDownExpandButton, showDrillDownLevelButton, showDrillToggleButton,
    showDrillUpButton, showDrillRoleSelector, showCommentButton,
    showCopyVisualImageButton, showSetAlertButton, plus the diagnostic
    showVisualInformationButton/showVisualWarningButton/showVisualErrorButton.
  - Sorting fix only flips existing Descending sorts to Ascending; it never
    invents a new sort where none exists.
  - Visual *groups* (layout containers with a "visualGroup" key instead of
    "visual", e.g. a page's "Footer" group) are not real visuals and have no
    header icons - the scanner skips them entirely.
"""
from __future__ import annotations
import copy
import json
import os
import re
from typing import Any, Optional

from . import jsonutil
from .appdirs import resource_base_dir
from .models import Finding, VisualRef

# Bundled, read-only config - resource_base_dir() (not app_base_dir()) since
# a --onefile build extracts this to a temp folder on each launch rather
# than keeping it next to the .exe. Editing it means rebuilding the .exe.
_CONFIG_PATH = os.path.join(resource_base_dir(), "config", "rule_config.json")

RULE_SLICER_HEADER = "slicer_header_disabled"
RULE_VISUAL_HEADER_FOCUS = "visual_header_focus_only"
RULE_SORT_ASCENDING = "sort_ascending"
RULE_COLOR_PALETTE = "color_palette_compliance"
RULE_EXPORT_DISABLED = "export_disabled"
RULE_FILTERS_LOCKED_HIDDEN = "filters_locked_hidden"
RULE_LEGEND_BOLD = "legend_bold"
RULE_DATA_SOURCE_REVIEW = "data_source_review"

RULE_LABELS = {
    RULE_SLICER_HEADER: "Slicer header icons must be disabled",
    RULE_VISUAL_HEADER_FOCUS: "Visual header icons must show only Focus mode",
    RULE_SORT_ASCENDING: "Sort direction must be ascending",
    RULE_COLOR_PALETTE: "Visual colors must follow the approved brand palette",
    RULE_EXPORT_DISABLED: "Export must be disabled or restricted to summarized data",
    RULE_FILTERS_LOCKED_HIDDEN: "Actively-used filters must be locked and hidden",
    RULE_LEGEND_BOLD: "Visual legends must be bold",
    RULE_DATA_SOURCE_REVIEW: "Data source connections should be reviewed",
}

ALL_RULE_IDS = [
    RULE_SLICER_HEADER, RULE_VISUAL_HEADER_FOCUS, RULE_SORT_ASCENDING, RULE_COLOR_PALETTE,
    RULE_EXPORT_DISABLED, RULE_FILTERS_LOCKED_HIDDEN, RULE_LEGEND_BOLD, RULE_DATA_SOURCE_REVIEW,
]

# Verified directly from a real visual.json written by Power BI Desktop
# (visualContainer schema 2.12.0). "Focus mode" is deliberately absent: PBI
# has no dedicated property for it, so it can only ever be left at its
# (enabled) default - never set explicitly.
_DEFAULT_ICON_PROPS = {
    "visual_information": "showVisualInformationButton",
    "visual_warning": "showVisualWarningButton",
    "visual_error": "showVisualErrorButton",
    "drill_role_selector": "showDrillRoleSelector",
    "drill_up": "showDrillUpButton",
    "drill_toggle": "showDrillToggleButton",
    "drill_down_level": "showDrillDownLevelButton",
    "drill_down_expand": "showDrillDownExpandButton",
    "pin": "showPinButton",
    "see_data": "showSeeDataLayoutToggleButton",
    "options": "showOptionsMenu",
    "filter": "showFilterRestatementButton",
    "comment": "showCommentButton",
    "copy_image": "showCopyVisualImageButton",
    "set_alert": "showSetAlertButton",
}
_DEFAULT_NO_HEADER_TYPES = {
    "textbox", "image", "shape", "actionbutton", "basicshape", "wordcloud", "qnavisual",
}
# Source of truth: the "Power BI Sequence" sheet in
# WTW_Data_Visualization_Color_Catalog.xlsx (order matters - it's meant to be
# used as-is for a report theme's dataColors array).
_DEFAULT_APPROVED_PALETTE = [
    "#521380", "#24A19B", "#4A91F4", "#CA8100", "#E76F00",
    "#E954D3", "#F75784", "#995BC5", "#1A71EF", "#C25700",
]
# Object names (as they appear under a visual's "objects", or under a theme's
# visualStyles.<type>.<variant>) that hold actual data/series colors - NOT
# text, labels, axes, legends, titles or gridlines. Deliberately excludes
# "fill" - on chart-type visuals it isn't used, and on UI elements (buttons,
# shapes, page navigators) it's chrome/branding, not a data color. Editable
# via config/rule_config.json.
_DEFAULT_COLOR_OBJECT_ALLOWLIST = [
    "dataPoint", "colors", "plotArea", "dataBars", "tree", "ribbonChart",
]
# report.json's settings.exportDataMode values that are NOT a violation.
# "None" (export fully disabled) is definitely correct - confirmed directly
# from a real report.json. "AllowSummarized" (summarized-data-only export) is
# the best-evidenced name for the other value the user explicitly said should
# also be acceptable ("we can allow summarized data or current layout data") -
# Microsoft doesn't publish an authoritative enum list for this property, so
# this is deliberately editable via config/rule_config.json if a project uses
# a different exact string for that same "summarized only" setting.
_DEFAULT_EXPORT_COMPLIANT_VALUES = ["None", "AllowSummarized"]


def _load_config():
    icons, no_header = dict(_DEFAULT_ICON_PROPS), set(_DEFAULT_NO_HEADER_TYPES)
    palette, color_objs = list(_DEFAULT_APPROVED_PALETTE), list(_DEFAULT_COLOR_OBJECT_ALLOWLIST)
    export_ok = list(_DEFAULT_EXPORT_COMPLIANT_VALUES)
    try:
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        if isinstance(cfg.get("icons"), dict) and cfg["icons"]:
            icons = cfg["icons"]
        if isinstance(cfg.get("no_header_visual_types"), list):
            no_header = {t.lower() for t in cfg["no_header_visual_types"]}
        if isinstance(cfg.get("approved_palette"), list) and cfg["approved_palette"]:
            palette = [str(c).upper() for c in cfg["approved_palette"]]
        if isinstance(cfg.get("color_object_allowlist"), list) and cfg["color_object_allowlist"]:
            color_objs = cfg["color_object_allowlist"]
        if isinstance(cfg.get("export_compliant_values"), list) and cfg["export_compliant_values"]:
            export_ok = [str(v) for v in cfg["export_compliant_values"]]
    except Exception:
        pass  # fall back to hardcoded defaults; config file is optional
    return icons, no_header, palette, color_objs, export_ok


# The icon properties that live under visualHeader / vcObjects.visualHeader,
# all of which must be disabled for rule 2 (everything except Focus mode,
# which is never written - see module docstring). Editable via
# config/rule_config.json.
ICON_PROPS, NO_HEADER_VISUAL_TYPES, APPROVED_PALETTE, COLOR_OBJECT_ALLOWLIST, EXPORT_COMPLIANT_VALUES = _load_config()
APPROVED_PALETTE_SET = set(APPROVED_PALETTE)


def header_key_for_format(fmt: str) -> str:
    return "visualContainerObjects" if fmt == "pbir" else "vcObjects"


def load_visual_json(visual: VisualRef):
    """Returns (file_root_json, visual_obj) for the given VisualRef, freshly
    read from disk. visual_obj is the nested dict that holds visualType /
    visualContainerObjects / query, etc. for PBIR, or singleVisual for legacy."""
    with open(visual.file_path, "r", encoding="utf-8") as f:
        root = json.load(f)

    if visual.format == "pbir":
        return root, root.get("visual", {})

    # legacy: root is the whole report.json; drill down to the right
    # visualContainer, then json-decode its "config" string.
    section = root["sections"][visual.page_index]
    container = section["visualContainers"][visual.container_index]
    config = json.loads(container["config"])
    return root, config.get("singleVisual", {})


def save_visual_json(visual: VisualRef, root: dict, visual_obj: dict, config: Optional[dict] = None) -> None:
    if visual.format == "pbir":
        root["visual"] = visual_obj
        with open(visual.file_path, "w", encoding="utf-8") as f:
            json.dump(root, f, indent=2, ensure_ascii=False)
            f.write("\n")
        return

    # legacy: config is the full decoded "config" object; visual_obj IS
    # config["singleVisual"], already mutated in place since dicts are
    # references. Re-encode config back into the container's config STRING.
    section = root["sections"][visual.page_index]
    container = section["visualContainers"][visual.container_index]
    container["config"] = json.dumps(config, ensure_ascii=False)
    with open(visual.file_path, "w", encoding="utf-8") as f:
        json.dump(root, f, indent=2, ensure_ascii=False)
        f.write("\n")


def _get_header_properties(visual_obj: dict, fmt: str, ensure: bool):
    """Return the `properties` dict inside visualHeader[0], or {} if absent
    and ensure=False. If ensure=True, creates the structure as needed and
    returns the live dict for mutation."""
    key = header_key_for_format(fmt)
    container = visual_obj.get(key)
    if container is None:
        if not ensure:
            return {}
        container = {}
        visual_obj[key] = container

    header_list = container.get("visualHeader")
    if not header_list:
        if not ensure:
            return {}
        header_list = [{"properties": {}}]
        container["visualHeader"] = header_list

    entry = header_list[0]
    props = entry.get("properties")
    if props is None:
        if not ensure:
            return {}
        props = {}
        entry["properties"] = props
    return props


def is_slicer(visual_type: str) -> bool:
    return "slicer" in (visual_type or "").lower()


def applies_to_header_rules(visual_type: str) -> bool:
    return (visual_type or "").lower() not in NO_HEADER_VISUAL_TYPES


def check_header_rules(visual: VisualRef) -> list[Finding]:
    findings: list[Finding] = []
    if not applies_to_header_rules(visual.visual_type):
        return findings

    _, visual_obj = load_visual_json(visual)
    props = _get_header_properties(visual_obj, visual.format, ensure=False)

    if is_slicer(visual.visual_type):
        show = jsonutil.read_bool(props.get("show"))
        is_disabled = show is False
        if not is_disabled:
            findings.append(Finding(
                rule_id=RULE_SLICER_HEADER,
                rule_label=RULE_LABELS[RULE_SLICER_HEADER],
                visual=visual,
                detail="Header icons are currently "
                       + ("shown (default)" if show is None else "enabled")
                       + " on this slicer.",
                fix_payload={},
            ))
    else:
        # "show" (the header itself) must not be explicitly disabled. Absent
        # = default = on, which is correct - only an explicit False is wrong.
        show = jsonutil.read_bool(props.get("show"))
        header_off = show is False

        bad_icons = []
        for label, prop_name in ICON_PROPS.items():
            val = jsonutil.read_bool(props.get(prop_name))
            if val is not False:
                bad_icons.append(label.replace("_", " ").title())

        if header_off or bad_icons:
            chips = (["Header off"] if header_off else []) + bad_icons
            if header_off:
                summary = "Header is off - should stay on, showing only Focus mode"
            else:
                summary = f"{len(bad_icons)} icon{'s' if len(bad_icons) != 1 else ''} still enabled"
            findings.append(Finding(
                rule_id=RULE_VISUAL_HEADER_FOCUS,
                rule_label=RULE_LABELS[RULE_VISUAL_HEADER_FOCUS],
                visual=visual,
                detail=summary,
                items=chips,
                fix_payload={},
            ))
    return findings


def _walk_for_descending(obj, path):
    """Yield (path_list, current_repr) for direction fields set to Descending.

    Skips any sort whose enclosing sortDefinition is Power BI's own
    automatic default (`"isDefaultSort": true`) rather than something a
    report author actually configured. Verified against a real 1200+ visual
    production PBIP: every Card visual (and plenty of others - lineChart
    included) carries an auto-generated "sort by the first measure,
    Descending, isDefaultSort: true" query artifact. It has no user-facing
    sort control at all (Cards can't be sorted from the UI) and doesn't
    reflect an author's choice, so flagging/fixing it would be a false
    positive. A real, author-set sort either omits `isDefaultSort` entirely
    or has it explicitly `false` - both cases still get walked normally."""
    if isinstance(obj, dict):
        if isinstance(obj.get("sort"), list) and obj.get("isDefaultSort") is True:
            return
        for k, v in obj.items():
            if k.lower() == "direction":
                if v == "Descending" or v == 2:
                    yield (path + [k], v)
            else:
                yield from _walk_for_descending(v, path + [k])
    elif isinstance(obj, list):
        for i, item in enumerate(obj):
            yield from _walk_for_descending(item, path + [i])


def check_sort_rule(visual: VisualRef) -> list[Finding]:
    findings = []
    _, visual_obj = load_visual_json(visual)
    for path, current in _walk_for_descending(visual_obj, []):
        findings.append(Finding(
            rule_id=RULE_SORT_ASCENDING,
            rule_label=RULE_LABELS[RULE_SORT_ASCENDING],
            visual=visual,
            detail=f"Sort direction is Descending at `{'/'.join(map(str, path))}`.",
            fix_payload={"path": path, "was": current},
        ))
    return findings


def _extract_literal_hex(color_value: Any) -> Optional[str]:
    """Returns an uppercased '#RRGGBB' if color_value is a literal hex color
    (plain string or {"expr":{"Literal":{"Value":"'#RRGGBB'"}}}). Returns
    None for anything else, notably a {"expr":{"ThemeDataColor":...}}
    reference - that's a visual correctly inheriting from the report theme,
    not a hardcoded override, so it's not flagged here (the theme itself is
    checked separately by check_theme_colors)."""
    if isinstance(color_value, str) and color_value.startswith("#"):
        return color_value.upper()
    if isinstance(color_value, dict):
        lit = color_value.get("expr", {}).get("Literal", {}).get("Value")
        if isinstance(lit, str):
            s = lit.strip().strip("'\"")
            if s.startswith("#"):
                return s.upper()
    return None


def _find_hex_paths(node: Any, path: list):
    """Yields (path_to_color_value, hex) for every literal hex color found
    anywhere under `node`, matching Power BI's `{"solid": {"color": <value>}}`
    fill/color shape. path_to_color_value is relative to `node` and always
    ends in ["solid", "color"] - exactly what a fixer needs to walk down to
    and overwrite. Stops descending once inside a color object (no reason to
    look further)."""
    if isinstance(node, dict):
        solid = node.get("solid")
        if isinstance(solid, dict) and "color" in solid:
            hexv = _extract_literal_hex(solid["color"])
            if hexv:
                yield (path + ["solid", "color"], hexv)
            return
        for k, v in node.items():
            yield from _find_hex_paths(v, path + [k])
    elif isinstance(node, list):
        for i, item in enumerate(node):
            yield from _find_hex_paths(item, path + [i])


def _hex_to_rgb(hexv: str):
    h = hexv.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _nearest_palette_color(hexv: str) -> str:
    """Closest approved-palette color by plain Euclidean RGB distance - the
    deterministic, explainable replacement used when the user opts a
    manual-review color finding into "Fix Selected"."""
    try:
        r1, g1, b1 = _hex_to_rgb(hexv)
    except Exception:
        return APPROVED_PALETTE[0]
    best, best_d = APPROVED_PALETTE[0], None
    for c in APPROVED_PALETTE:
        r2, g2, b2 = _hex_to_rgb(c)
        d = (r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2
        if best_d is None or d < best_d:
            best, best_d = c, d
    return best


def check_visual_colors(visual: VisualRef) -> list[Finding]:
    """Rule 4 (per-visual half): flags literal/hardcoded colors on a visual's
    own data-color properties (dataPoint, colors, plotArea, ...) that aren't
    in the approved palette. Deliberately does NOT look at text/label/axis/
    legend/title/gridline properties.

    This IS fixable (snap each occurrence to its nearest approved-palette
    color by RGB distance), but auto_select=False - there's no way to know
    the *intended* color, so it's left unchecked by default and excluded
    from "select all" / "select all pages"; the user opts individual ones in
    after eyeballing whether a nearest-match snap is acceptable."""
    findings: list[Finding] = []
    if not APPROVED_PALETTE:
        return findings
    _, visual_obj = load_visual_json(visual)
    objects = visual_obj.get("objects")
    if not isinstance(objects, dict):
        return findings

    occurrences = []
    seen: dict[str, str] = {}
    for obj_name in COLOR_OBJECT_ALLOWLIST:
        if obj_name in objects:
            for relpath, hexv in _find_hex_paths(objects[obj_name], []):
                if hexv not in APPROVED_PALETTE_SET:
                    nearest = seen.get(hexv) or _nearest_palette_color(hexv)
                    seen[hexv] = nearest
                    occurrences.append({"path": ["objects", obj_name] + relpath, "hex": hexv, "nearest": nearest})

    if occurrences:
        findings.append(Finding(
            rule_id=RULE_COLOR_PALETTE,
            rule_label=RULE_LABELS[RULE_COLOR_PALETTE],
            visual=visual,
            detail=f"Uses {len(seen)} color{'s' if len(seen) != 1 else ''} not in the "
                   f"approved WTW palette.",
            items=list(seen.keys()),
            expected=list(seen.values()),
            fixable=True,
            auto_select=False,
            fix_payload={"kind": "nearest_match_colors", "occurrences": occurrences},
        ))
    return findings


def _find_theme_file(report_folder: str) -> tuple[Optional[str], str]:
    """Resolves the report's custom theme JSON file on disk, if it has one.
    Returns (path, "") on success, or (None, reason) - the reason is
    surfaced as a scan warning so a silent "theme not checked" outcome is
    always explainable instead of just quietly producing zero findings."""
    report_json_path = os.path.join(report_folder, "definition", "report.json")
    if not os.path.isfile(report_json_path):
        report_json_path = os.path.join(report_folder, "report.json")
    if not os.path.isfile(report_json_path):
        return None, f"no report.json found (looked for {report_json_path})"
    try:
        with open(report_json_path, "r", encoding="utf-8") as f:
            report_json = json.load(f)
    except Exception as e:
        return None, f"could not parse {report_json_path}: {e}"

    custom = report_json.get("themeCollection", {}).get("customTheme")
    if not isinstance(custom, dict):
        return None, ("report.json has no themeCollection.customTheme - this report may only be using "
                       "a built-in Power BI theme, which has no local file to check")
    theme_name = custom.get("name")
    theme_type = custom.get("type", "RegisteredResources")

    checked_paths = []
    for pkg in report_json.get("resourcePackages", []):
        if pkg.get("type") != theme_type:
            continue
        for item in pkg.get("items", []):
            if item.get("type") == "CustomTheme" or item.get("name") == theme_name:
                rel = item.get("path") or theme_name
                if not rel:
                    continue
                candidate = os.path.join(report_folder, "StaticResources", pkg.get("name", theme_type), rel)
                checked_paths.append(candidate)
                if os.path.isfile(candidate):
                    return candidate, ""
    if checked_paths:
        return None, (f"customTheme references '{theme_name}' but no file was found on disk - "
                       f"looked at: {', '.join(checked_paths)}")
    return None, (f"customTheme references '{theme_name}' (type '{theme_type}') but no matching entry "
                   f"was found in report.json's resourcePackages")


def check_theme_colors(report_folder: str, warnings: Optional[list] = None) -> list[Finding]:
    """Rule 4 (theme half): (a) the report's custom theme's `dataColors`
    array must match the approved palette exactly, in order - this IS safely
    auto-fixable (it's just overwriting one array with the known-correct
    one); (b) any per-visual-type default style baked into the theme
    (e.g. every columnChart defaulting to some other purple) that uses a
    non-approved color is flagged for manual review, same reasoning as
    check_visual_colors.

    If `warnings` is given, appends a human-readable reason whenever the
    theme couldn't be located/parsed at all, so "0 theme findings" is always
    explainable (rather than silently meaning either "compliant" or "not
    checked" with no way to tell them apart)."""
    findings: list[Finding] = []
    report_name = os.path.basename(report_folder)
    if not APPROVED_PALETTE:
        return findings
    theme_path, reason = _find_theme_file(report_folder)
    if not theme_path:
        if warnings is not None:
            warnings.append(f"Color palette: could not check '{report_name}''s report theme - {reason}.")
        return findings
    try:
        with open(theme_path, "r", encoding="utf-8") as f:
            theme = json.load(f)
    except Exception as e:
        if warnings is not None:
            warnings.append(f"Color palette: found theme file for '{report_name}' but could not parse it - {e}.")
        return findings

    def _theme_visual(visual_id: str, visual_type: str, title: str) -> VisualRef:
        return VisualRef(
            id=f"{report_name}|__theme__|{visual_id}",
            report_name=report_name,
            report_path=report_folder,
            page_id="__theme__",
            page_name="(Report Theme)",
            visual_id=visual_id,
            visual_type=visual_type,
            title=title,
            file_path=theme_path,
            format="theme",
        )

    current = [str(c).upper() for c in theme.get("dataColors", []) if isinstance(c, str)]
    if current != APPROVED_PALETTE:
        findings.append(Finding(
            rule_id=RULE_COLOR_PALETTE,
            rule_label=RULE_LABELS[RULE_COLOR_PALETTE],
            visual=_theme_visual("dataColors", "theme", os.path.basename(theme_path)),
            detail="Report theme's dataColors sequence doesn't match the approved WTW palette (order matters).",
            items=current,
            expected=APPROVED_PALETTE,
            fixable=True,
            auto_select=True,
            fix_payload={"kind": "theme_data_colors", "expected": APPROVED_PALETTE},
        ))

    occurrences_by_type: dict[str, list] = {}
    visual_styles = theme.get("visualStyles")
    if isinstance(visual_styles, dict):
        for vtype, variants in visual_styles.items():
            if not isinstance(variants, dict):
                continue
            for variant_key, variant_props in variants.items():
                if not isinstance(variant_props, dict):
                    continue
                for obj_name in COLOR_OBJECT_ALLOWLIST:
                    if obj_name in variant_props:
                        for relpath, hexv in _find_hex_paths(variant_props[obj_name], []):
                            if hexv not in APPROVED_PALETTE_SET:
                                full_path = ["visualStyles", vtype, variant_key, obj_name] + relpath
                                nearest = _nearest_palette_color(hexv)
                                occurrences_by_type.setdefault(vtype, []).append(
                                    {"path": full_path, "hex": hexv, "nearest": nearest}
                                )

    for vtype, occs in occurrences_by_type.items():
        seen: dict[str, str] = {}
        for o in occs:
            seen.setdefault(o["hex"], o["nearest"])
        findings.append(Finding(
            rule_id=RULE_COLOR_PALETTE,
            rule_label=RULE_LABELS[RULE_COLOR_PALETTE],
            visual=_theme_visual(f"style:{vtype}", f"theme style · {vtype}", f"Theme default style - {vtype}"),
            detail=f"Theme's default style for '{vtype}' visuals uses a color not in the "
                   f"approved palette.",
            items=list(seen.keys()),
            expected=list(seen.values()),
            fixable=True,
            auto_select=False,
            fix_payload={"kind": "nearest_match_colors", "occurrences": occs},
        ))

    return findings


def _find_report_json(report_folder: str) -> Optional[str]:
    path = os.path.join(report_folder, "definition", "report.json")
    if os.path.isfile(path):
        return path
    path = os.path.join(report_folder, "report.json")
    return path if os.path.isfile(path) else None


def check_export_disabled(report_folder: str, warnings: Optional[list] = None) -> list[Finding]:
    """Rule 5: report.json's settings.exportDataMode must not be a value that
    allows full/underlying-data export. Missing entirely also counts as a
    violation - Power BI's own default when nothing is set is unrestricted
    export, which is the least-restrictive (and least governed) state."""
    findings: list[Finding] = []
    report_name = os.path.basename(report_folder)
    report_json_path = _find_report_json(report_folder)
    if not report_json_path:
        return findings
    try:
        with open(report_json_path, "r", encoding="utf-8") as f:
            report_json = json.load(f)
    except Exception as e:
        if warnings is not None:
            warnings.append(f"Export setting: could not parse {report_json_path}: {e}.")
        return findings

    current = report_json.get("settings", {}).get("exportDataMode")
    if current in EXPORT_COMPLIANT_VALUES:
        return findings

    visual = VisualRef(
        id=f"{report_name}|__settings__|exportDataMode",
        report_name=report_name,
        report_path=report_folder,
        page_id="__report_settings__",
        page_name="(Report Settings)",
        visual_id="exportDataMode",
        visual_type="settings",
        title="Report export setting",
        file_path=report_json_path,
        format="report_root",
    )
    detail = (
        f"Export is set to '{current}', which permits exporting underlying data."
        if current is not None
        else "No export restriction is set (report.json has no settings.exportDataMode), "
             "which defaults to unrestricted export."
    )
    findings.append(Finding(
        rule_id=RULE_EXPORT_DISABLED,
        rule_label=RULE_LABELS[RULE_EXPORT_DISABLED],
        visual=visual,
        detail=detail,
        items=[str(current) if current is not None else "(not set)"],
        expected=["None"],
        fixable=True,
        auto_select=True,
        fix_payload={"kind": "export_data_mode", "value": "None"},
    ))
    return findings


def _filter_label(filt: dict) -> str:
    """Best-effort human-readable label for a filter entry - the column or
    measure name it's filtering on, falling back to its internal name."""
    field = filt.get("field", {})
    if isinstance(field, dict):
        for key in ("Column", "Measure", "HierarchyLevel"):
            node = field.get(key)
            if isinstance(node, dict) and node.get("Property"):
                return str(node["Property"])
    return str(filt.get("name", "filter"))


def _find_unlocked_active_filters(root: dict):
    """Yields (index, filt) for entries in root['filterConfig']['filters']
    that are actively applied (have a real `filter` condition - not just an
    empty card sitting in the panel with no value chosen) but aren't both
    locked AND hidden in view mode."""
    filters = (root.get("filterConfig") or {}).get("filters")
    if not isinstance(filters, list):
        return
    for i, filt in enumerate(filters):
        if not isinstance(filt, dict) or "filter" not in filt:
            continue
        locked = jsonutil.read_bool(filt.get("isLockedInViewMode")) is True
        hidden = jsonutil.read_bool(filt.get("isHiddenInViewMode")) is True
        if not (locked and hidden):
            yield i, filt


def check_report_filters(report_folder: str, warnings: Optional[list] = None) -> list[Finding]:
    """Rule 6 (report-level half): actively-used filters in the report-level
    filter pane (report.json's filterConfig.filters, a sibling of
    themeCollection at the file root) must be locked and hidden."""
    findings: list[Finding] = []
    report_name = os.path.basename(report_folder)
    report_json_path = _find_report_json(report_folder)
    if not report_json_path:
        return findings
    try:
        with open(report_json_path, "r", encoding="utf-8") as f:
            report_json = json.load(f)
    except Exception as e:
        if warnings is not None:
            warnings.append(f"Filter lock/hide: could not parse {report_json_path}: {e}.")
        return findings

    occurrences = list(_find_unlocked_active_filters(report_json))
    if not occurrences:
        return findings

    visual = VisualRef(
        id=f"{report_name}|__filters__|report",
        report_name=report_name,
        report_path=report_folder,
        page_id="__report_filters__",
        page_name="(Report Filters)",
        visual_id="report-filters",
        visual_type="filters",
        title="Report-level filter pane",
        file_path=report_json_path,
        format="report_root",
    )
    items = [_filter_label(f) for _, f in occurrences]
    n = len(occurrences)
    findings.append(Finding(
        rule_id=RULE_FILTERS_LOCKED_HIDDEN,
        rule_label=RULE_LABELS[RULE_FILTERS_LOCKED_HIDDEN],
        visual=visual,
        detail=f"{n} actively-used report-level filter{'s' if n != 1 else ''} "
               f"{'are' if n != 1 else 'is'} not both locked and hidden.",
        items=items,
        fixable=True,
        auto_select=True,
        fix_payload={"kind": "lock_hide_filters", "indices": [i for i, _ in occurrences]},
    ))
    return findings


def check_visual_filters(visual: VisualRef) -> list[Finding]:
    """Rule 6 (per-visual half): same check as check_report_filters, but for
    a single visual's own filter pane (visual.json's filterConfig, a sibling
    of "visual" at the file root - not nested inside the visual object
    itself). PBIR-only for now; legacy report.json encodes visual-level
    filters differently and isn't handled here yet."""
    if visual.format != "pbir":
        return []
    root, _ = load_visual_json(visual)
    occurrences = list(_find_unlocked_active_filters(root))
    if not occurrences:
        return []
    items = [_filter_label(f) for _, f in occurrences]
    n = len(occurrences)
    return [Finding(
        rule_id=RULE_FILTERS_LOCKED_HIDDEN,
        rule_label=RULE_LABELS[RULE_FILTERS_LOCKED_HIDDEN],
        visual=visual,
        detail=f"{n} actively-used filter{'s' if n != 1 else ''} on this visual "
               f"{'are' if n != 1 else 'is'} not both locked and hidden.",
        items=items,
        fixable=True,
        auto_select=True,
        fix_payload={"kind": "lock_hide_filters", "indices": [i for i, _ in occurrences]},
    )]


def check_legend_bold(visual: VisualRef) -> list[Finding]:
    """Rule 7: a visual's legend must not have bold explicitly turned off.
    The WTW theme already defaults legends to bold, so - mirroring the
    established pattern for rule 2's header icons - this only needs to catch
    an explicit override (objects.legend[].properties.bold === false);
    absence of the property means "inherits the theme's bold default",
    which is already correct."""
    _, visual_obj = load_visual_json(visual)
    objects = visual_obj.get("objects")
    if not isinstance(objects, dict):
        return []
    legend_list = objects.get("legend")
    if not isinstance(legend_list, list):
        return []
    for entry in legend_list:
        if not isinstance(entry, dict):
            continue
        props = entry.get("properties")
        if isinstance(props, dict) and jsonutil.read_bool(props.get("bold")) is False:
            return [Finding(
                rule_id=RULE_LEGEND_BOLD,
                rule_label=RULE_LABELS[RULE_LEGEND_BOLD],
                visual=visual,
                detail="Legend text is explicitly set to not bold.",
                fixable=True,
                auto_select=True,
                fix_payload={"kind": "legend_bold"},
            )]
    return []


_TMDL_FUNC_RE = re.compile(r"([A-Za-z][A-Za-z0-9_.]*)\s*\(")
_TMDL_STRING_RE = re.compile(r'"([^"]{3,300})"')


def _find_semantic_model_folder(report_folder: str) -> Optional[str]:
    """A PBIP's report and semantic model are sibling folders sharing the
    same base name (`<Name>.Report` / `<Name>.SemanticModel`), not nested
    inside each other."""
    parent = os.path.dirname(report_folder.rstrip("\\/"))
    base = os.path.basename(report_folder.rstrip("\\/"))
    if not base.lower().endswith(".report"):
        return None
    stem = base[: -len(".Report")]
    candidate = os.path.join(parent, stem + ".SemanticModel")
    if os.path.isdir(candidate):
        return candidate
    try:
        for name in os.listdir(parent):
            if name.lower() == (stem + ".SemanticModel").lower():
                return os.path.join(parent, name)
    except OSError:
        pass
    return None


def _iter_tmdl_files(semantic_model_folder: str):
    definition_dir = os.path.join(semantic_model_folder, "definition")
    if not os.path.isdir(definition_dir):
        return
    expr_path = os.path.join(definition_dir, "expressions.tmdl")
    if os.path.isfile(expr_path):
        yield expr_path
    tables_dir = os.path.join(definition_dir, "tables")
    if os.path.isdir(tables_dir):
        for name in sorted(os.listdir(tables_dir)):
            if name.lower().endswith(".tmdl"):
                yield os.path.join(tables_dir, name)


def _scan_tmdl_sources(path: str):
    """Yields (line_no, snippet, function_name, target) for each
    `Source = ...` statement found in a .tmdl file. TMDL is plain text (not
    JSON), so this is a best-effort scan good enough to surface a
    connection for a human to review - not a full M-language parser."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()
    except Exception:
        return
    for i, line in enumerate(lines):
        m = re.match(r"\s*[Ss]ource\s*=\s*(.+)$", line)
        if not m:
            continue
        snippet = m.group(1).strip()
        # The M expression can wrap onto following lines - cheaply pull in a
        # little more context if this line's parens aren't balanced yet.
        j = i
        while snippet.count("(") > snippet.count(")") and j + 1 < len(lines) and j - i < 5:
            j += 1
            snippet += " " + lines[j].strip()
        func_match = _TMDL_FUNC_RE.search(snippet)
        str_match = _TMDL_STRING_RE.search(snippet)
        yield i + 1, snippet[:220], (func_match.group(1) if func_match else None), \
            (str_match.group(1) if str_match else None)


def check_data_source_review(report_folder: str, warnings: Optional[list] = None) -> list[Finding]:
    """Rule 8: detection-only. Surfaces every data-source connection found
    in the report's paired semantic model so a human can review where the
    data is actually coming from (e.g. spot a report pulling straight from
    a SharePoint/Excel file or a specific server, rather than a governed
    source). There's no safe automatic fix for a data connection, so these
    findings are always fixable=False - they exist purely to be reviewed."""
    findings: list[Finding] = []
    report_name = os.path.basename(report_folder)
    sm_folder = _find_semantic_model_folder(report_folder)
    if not sm_folder:
        if warnings is not None:
            warnings.append(
                f"Data source review: could not find a .SemanticModel folder next to "
                f"'{report_name}' - nothing to check."
            )
        return findings

    for tmdl_path in _iter_tmdl_files(sm_folder):
        source_name = os.path.splitext(os.path.basename(tmdl_path))[0]
        for line_no, snippet, func_name, target in _scan_tmdl_sources(tmdl_path):
            if not func_name and not target:
                # `Source = SomePriorStepOrQueryName` with no function call
                # and no literal at all - just a step referencing another
                # already-loaded step/query by name, not an actual
                # connection. Nothing useful to review here.
                continue
            visual = VisualRef(
                id=f"{report_name}|__datasource__|{source_name}:{line_no}",
                report_name=report_name,
                report_path=report_folder,
                page_id="__data_source__",
                page_name="(Data Source)",
                visual_id=f"{source_name}:{line_no}",
                visual_type="data source",
                title=source_name,
                file_path=tmdl_path,
                format="tmdl",
            )
            detail = f"'{source_name}' connects via {func_name or 'an M expression'}"
            if target:
                detail += f" to: {target}"
            detail += " - review whether this is the intended data source."
            findings.append(Finding(
                rule_id=RULE_DATA_SOURCE_REVIEW,
                rule_label=RULE_LABELS[RULE_DATA_SOURCE_REVIEW],
                visual=visual,
                detail=detail,
                items=[target or func_name or snippet],
                fixable=False,
                auto_select=False,
                fix_payload={},
            ))
    return findings


def check_all(visual: VisualRef, enabled_rules: Optional[set] = None) -> list[Finding]:
    findings: list[Finding] = []
    if enabled_rules is None or RULE_SLICER_HEADER in enabled_rules or RULE_VISUAL_HEADER_FOCUS in enabled_rules:
        findings.extend(check_header_rules(visual))
    if enabled_rules is None or RULE_SORT_ASCENDING in enabled_rules:
        findings.extend(check_sort_rule(visual))
    if enabled_rules is None or RULE_COLOR_PALETTE in enabled_rules:
        findings.extend(check_visual_colors(visual))
    if enabled_rules is None or RULE_FILTERS_LOCKED_HIDDEN in enabled_rules:
        findings.extend(check_visual_filters(visual))
    if enabled_rules is None or RULE_LEGEND_BOLD in enabled_rules:
        findings.extend(check_legend_bold(visual))
    if enabled_rules is not None:
        findings = [f for f in findings if f.rule_id in enabled_rules]
    return findings
