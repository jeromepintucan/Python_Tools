from __future__ import annotations
import json
import os
from typing import Any

from . import jsonutil
from . import backup as backup_mod
from .rules import (
    RULE_SLICER_HEADER, RULE_VISUAL_HEADER_FOCUS, RULE_SORT_ASCENDING, RULE_COLOR_PALETTE,
    RULE_EXPORT_DISABLED, RULE_FILTERS_LOCKED_HIDDEN, RULE_LEGEND_BOLD,
    ICON_PROPS, _get_header_properties,
)
from .models import Finding


def _visual_key(v) -> str:
    return f"{v.page_id}|{v.visual_id}|{v.container_index}"


def _apply_single(visual_obj: dict, finding: Finding) -> None:
    """Mutates `visual_obj` in place per `finding`. Despite the parameter
    name, for some rules (RULE_COLOR_PALETTE's theme kind, RULE_EXPORT_
    DISABLED, RULE_FILTERS_LOCKED_HIDDEN's report-level finding) the caller
    passes the whole file's root JSON instead of the nested visual object -
    see apply_fixes() below for which container each rule/format needs."""
    fmt = finding.visual.format
    if finding.rule_id == RULE_SLICER_HEADER:
        props = _get_header_properties(visual_obj, fmt, ensure=True)
        jsonutil.set_bool(props, "show", False)

    elif finding.rule_id == RULE_VISUAL_HEADER_FOCUS:
        props = _get_header_properties(visual_obj, fmt, ensure=True)
        # Only touch "show" if it was explicitly disabled - Power BI itself
        # never writes "show": true (that's the default), so we don't
        # either; we just make sure it isn't explicitly False. Focus mode
        # has no dedicated property at all, so it's never written - leaving
        # it alone is exactly what keeps it enabled.
        if jsonutil.read_bool(props.get("show")) is False:
            jsonutil.set_bool(props, "show", True)
        for label, prop_name in ICON_PROPS.items():
            jsonutil.set_bool(props, prop_name, False)

    elif finding.rule_id == RULE_SORT_ASCENDING:
        path = finding.fix_payload["path"]
        target: Any = visual_obj
        for p in path[:-1]:
            target = target[p]
        last_key = path[-1]
        current = target[last_key]
        target[last_key] = 1 if current == 2 else "Ascending"

    elif finding.rule_id == RULE_COLOR_PALETTE:
        kind = (finding.fix_payload or {}).get("kind")
        if kind == "theme_data_colors":
            # There's exactly one correct value here (the approved
            # sequence), so this is always safely auto-fixable.
            visual_obj["dataColors"] = list(finding.fix_payload["expected"])
        elif kind == "nearest_match_colors":
            # Only reached if the user deliberately checked this finding
            # (auto_select=False keeps it out of "select all"/"Fix Selected"
            # by default). Snaps every occurrence of the hardcoded color to
            # its nearest approved-palette match by RGB distance, preserving
            # whichever value encoding (plain string vs Literal-wrapped) was
            # already there.
            for occ in finding.fix_payload.get("occurrences", []):
                path, nearest = occ["path"], occ["nearest"]
                target: Any = visual_obj
                try:
                    for p in path[:-1]:
                        target = target[p]
                    last_key = path[-1]
                    current = target[last_key]
                except (KeyError, IndexError, TypeError):
                    continue
                if isinstance(current, dict):
                    lit = current.get("expr", {}).get("Literal", {})
                    if isinstance(lit, dict) and "Value" in lit:
                        orig = str(lit["Value"]).strip()
                        quote = orig[0] if orig[:1] in ("'", '"') else "'"
                        lit["Value"] = f"{quote}{nearest}{quote}"
                    else:
                        target[last_key] = nearest
                else:
                    target[last_key] = nearest

    elif finding.rule_id == RULE_EXPORT_DISABLED:
        # visual_obj here is the report.json root (format="report_root").
        settings = visual_obj.get("settings")
        if not isinstance(settings, dict):
            settings = {}
            visual_obj["settings"] = settings
        settings["exportDataMode"] = finding.fix_payload.get("value", "None")

    elif finding.rule_id == RULE_FILTERS_LOCKED_HIDDEN:
        # visual_obj here is either the report.json root (report-level
        # finding, format="report_root") or a visual.json's file root
        # (per-visual finding, format="pbir" - filterConfig sits at the file
        # root, a sibling of "visual", not nested inside the visual object;
        # apply_fixes() below passes `root` rather than the usual visual_obj
        # for exactly this rule).
        filters = (visual_obj.get("filterConfig") or {}).get("filters")
        if isinstance(filters, list):
            for i in finding.fix_payload.get("indices", []):
                if 0 <= i < len(filters) and isinstance(filters[i], dict):
                    # NOTE: unlike visual "objects.X[].properties" bindings,
                    # a filter entry's isLockedInViewMode/isHiddenInViewMode
                    # are plain JSON booleans in the PBIR schema - never the
                    # {"expr":{"Literal":{"Value":...}}} wrapper used for
                    # format-pane properties. jsonutil.set_bool() was wrong
                    # here (it defaults to the wrapped style when it can't
                    # detect a sibling's style, which is exactly what
                    # happened - "howCreated" is a string, not a bool) and
                    # produced a value Power BI Desktop rejects outright as
                    # the wrong type. Write plain booleans directly.
                    filters[i]["isLockedInViewMode"] = True
                    filters[i]["isHiddenInViewMode"] = True

    elif finding.rule_id == RULE_LEGEND_BOLD:
        objects = visual_obj.get("objects")
        if not isinstance(objects, dict):
            objects = {}
            visual_obj["objects"] = objects
        legend_list = objects.get("legend")
        if not isinstance(legend_list, list) or not legend_list:
            legend_list = [{"properties": {}}]
            objects["legend"] = legend_list
        for entry in legend_list:
            if isinstance(entry, dict):
                props = entry.get("properties")
                if not isinstance(props, dict):
                    props = {}
                    entry["properties"] = props
                jsonutil.set_bool(props, "bold", True)


def apply_fixes(root_path: str, findings: list[Finding]) -> dict:
    """Applies a list of previously-scanned Findings. Groups by file so each
    file is read once, patched in memory, and written once. Backs up every
    affected file before touching it."""
    file_groups: dict[str, list[Finding]] = {}
    for f in findings:
        file_groups.setdefault(f.visual.file_path, []).append(f)

    backup_folder = backup_mod.backup_files(root_path, list(file_groups.keys()))

    applied, failed = [], []

    for file_path, group in file_groups.items():
        fmt = group[0].visual.format
        try:
            with open(file_path, "r", encoding="utf-8") as fh:
                root = json.load(fh)

            if fmt in ("theme", "report_root"):
                # Theme JSON and report.json-level findings (export setting,
                # report-level filters) have no per-visual wrapper - the
                # thing to patch is the file's root object itself, so patch
                # it in place and skip the visual-container bookkeeping
                # below entirely.
                for finding in group:
                    _apply_single(root, finding)
                with open(file_path, "w", encoding="utf-8") as fh:
                    json.dump(root, fh, indent=2, ensure_ascii=False)
                    fh.write("\n")
                applied.extend(f.id for f in group)
                continue

            by_visual: dict[str, list[Finding]] = {}
            for f in group:
                by_visual.setdefault(_visual_key(f.visual), []).append(f)

            for _key, vfindings in by_visual.items():
                visual = vfindings[0].visual
                config = None
                if fmt == "pbir":
                    visual_obj = root.get("visual", {})
                else:
                    section = root["sections"][visual.page_index]
                    container = section["visualContainers"][visual.container_index]
                    config = json.loads(container["config"])
                    visual_obj = config.get("singleVisual", {})

                for finding in vfindings:
                    if fmt == "pbir" and finding.rule_id == RULE_FILTERS_LOCKED_HIDDEN:
                        # filterConfig sits at the visual.json file root, a
                        # sibling of "visual" - not inside visual_obj itself.
                        _apply_single(root, finding)
                    else:
                        _apply_single(visual_obj, finding)

                if fmt != "pbir":
                    section = root["sections"][visual.page_index]
                    container = section["visualContainers"][visual.container_index]
                    container["config"] = json.dumps(config, ensure_ascii=False)

            with open(file_path, "w", encoding="utf-8") as fh:
                json.dump(root, fh, indent=2, ensure_ascii=False)
                fh.write("\n")

            applied.extend(f.id for f in group)
        except Exception as e:
            failed.extend({"id": f.id, "error": str(e)} for f in group)

    return {
        "backup_folder": backup_folder,
        "applied_count": len(applied),
        "failed_count": len(failed),
        "applied": applied,
        "failed": failed,
    }
