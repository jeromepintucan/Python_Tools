from __future__ import annotations
import os
from typing import Optional

from . import scanner, rules, fixer
from .models import ScanResult


def run_scan(root_path: str, enabled_rules: Optional[list] = None) -> ScanResult:
    """enabled_rules: list of rule ids from rules.ALL_RULE_IDS to actually
    check (the pre-scan checklist in the UI). None/empty-list-not-passed
    means "run everything" - kept backwards compatible for any other caller."""
    root_path = os.path.abspath(root_path)
    result = ScanResult(root_path=root_path)
    rule_set = set(enabled_rules) if enabled_rules else None

    report_folders = list(scanner.find_report_folders(root_path))
    if not report_folders:
        result.warnings.append(
            "No *.Report folder was found under the selected path. Make sure "
            "you selected the folder that contains your .pbip file (or a "
            "parent folder containing one or more PBIP projects)."
        )
        return result

    seen_pages = set()
    for report_folder in report_folders:
        result.reports_scanned.append(os.path.basename(report_folder))
        legacy = scanner.is_legacy_report(report_folder)
        if legacy:
            result.warnings.append(
                f"'{os.path.basename(report_folder)}' uses the legacy "
                f"(non-PBIR) report.json format. Support for this format is "
                f"best-effort — review fixes carefully before trusting them."
            )
            visuals = list(scanner.scan_legacy_report(report_folder))
        else:
            visuals = list(scanner.scan_pbir_report(report_folder))

        if rule_set is None or rules.RULE_COLOR_PALETTE in rule_set:
            try:
                result.findings.extend(rules.check_theme_colors(report_folder, result.warnings))
            except Exception as e:
                result.warnings.append(
                    f"Could not check theme colors for '{os.path.basename(report_folder)}': {e}"
                )

        if rule_set is None or rules.RULE_EXPORT_DISABLED in rule_set:
            try:
                result.findings.extend(rules.check_export_disabled(report_folder, result.warnings))
            except Exception as e:
                result.warnings.append(
                    f"Could not check export setting for '{os.path.basename(report_folder)}': {e}"
                )

        if rule_set is None or rules.RULE_FILTERS_LOCKED_HIDDEN in rule_set:
            try:
                result.findings.extend(rules.check_report_filters(report_folder, result.warnings))
            except Exception as e:
                result.warnings.append(
                    f"Could not check report-level filters for '{os.path.basename(report_folder)}': {e}"
                )

        if rule_set is None or rules.RULE_DATA_SOURCE_REVIEW in rule_set:
            try:
                result.findings.extend(rules.check_data_source_review(report_folder, result.warnings))
            except Exception as e:
                result.warnings.append(
                    f"Could not check data source connections for '{os.path.basename(report_folder)}': {e}"
                )

        for v in visuals:
            seen_pages.add((v.report_name, v.page_id))
            result.visuals_scanned += 1
            try:
                result.findings.extend(rules.check_all(v, rule_set))
            except Exception as e:
                result.warnings.append(
                    f"Could not analyze visual '{v.visual_id}' on page "
                    f"'{v.page_name}' ({v.report_name}): {e}"
                )

    result.pages_scanned = len(seen_pages)
    return result


def apply_fixes(root_path: str, scan_result: ScanResult, finding_ids: list[str]) -> dict:
    id_set = set(finding_ids)
    # f.fixable guard is defensive: detect-only findings (e.g. hardcoded
    # colors with no safe automatic replacement) should never actually be
    # written even if an id somehow ends up selected.
    selected = [f for f in scan_result.findings if f.id in id_set and f.fixable]
    if not selected:
        return {"backup_folder": None, "applied_count": 0, "failed_count": 0, "applied": [], "failed": []}
    return fixer.apply_fixes(root_path, selected)
