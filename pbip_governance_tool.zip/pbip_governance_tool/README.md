# PBIP Governance Assistant

A small desktop app that scans a Power BI Project (PBIP) folder against seven
governance conventions, shows you exactly what's wrong and where, and can
auto-fix whatever's safely fixable — with an automatic backup before it
touches anything. Before each scan, a checklist lets you pick which checks to
actually run.

## The rules

1. **Slicers** — the "Header icons" section (Format pane → General → Header
   icons) must be **disabled** on every slicer.
2. **All other visuals** — header icons must be **enabled**, but with
   **only the Focus mode icon on**. Every other icon (Options `...`, Filter,
   Pin, Drill, See data) is turned off. Power BI has no native "show icons
   only while in focus mode" toggle, so this is the closest real
   equivalent: a clean header that still lets people expand a visual.
3. **Sorting** — any visual that already has an explicit, author-set sort
   configured must sort **Ascending**. The tool only flips the direction of
   an *existing* sort (same field); it never invents a sort where none
   exists. It also ignores Power BI's own auto-generated default sort
   (`isDefaultSort: true` in the query definition) - verified against a real
   1200+ visual project, every Card visual (and others) carries a harmless
   "sort by the first measure, Descending" artifact with no user-facing sort
   control at all; flagging that would be a false positive, so only sorts a
   report author actually configured are checked.
4. **Color palette** — visual/data colors must come from the approved WTW
   brand sequence (from `WTW_Data_Visualization_Color_Catalog.xlsx`'s
   "Power BI Sequence" sheet — shown as swatches right in the app so you can
   see the reference at a glance). This checks two things:
   - The report's **custom theme file**'s `dataColors` array must match the
     approved 10-color sequence exactly, in order. There's exactly one
     correct value here, so this **is auto-selected** by "Fix Selected".
   - Any **hardcoded color** on a visual's own data properties (or baked
     into the theme's per-visual-type defaults) that isn't in the approved
     palette gets flagged too, shown with an arrow to the **nearest approved
     match** by color distance. These start **unchecked** ("Not
     auto-selected" badge) since there's no way to know the *intended*
     color automatically — but the checkbox isn't disabled: look at the
     current → nearest-match swatches, and if the snap looks right, check
     the box yourself to include it in "Fix Selected". "select all" /
     "select all pages" never sweeps these in automatically; it's always a
     deliberate per-item choice. This deliberately only looks at genuine
     data-color properties (`dataPoint`, `colors`, `plotArea`, `dataBars`,
     `tree`, `ribbonChart`) - text, labels, axes, legends, titles, gridlines
     and backgrounds are never touched or flagged.

   **Why most visuals aren't listed individually:** a visual only shows up
   here if it has a *hardcoded* color override. Most charts (pie, donut,
   treemap, etc.) don't set their own colors at all - they cycle through the
   report theme's `dataColors` sequence automatically, so if that sequence
   is wrong, every one of those visuals looks wrong on screen even though
   none of them are individually flagged. Fixing the one theme finding
   recolors all of them at once; the app says this explicitly above the
   findings list.
5. **Export** — the report's `Export data` setting (report.json's
   `settings.exportDataMode`) must not permit exporting the full underlying
   data. Fully disabled (`None`) or restricted to summarized data only
   (`AllowSummarized`) both count as compliant; anything else — including
   the setting being absent entirely, which Power BI treats as unrestricted
   — is flagged. The auto-fix always sets it to `None`, the one
   unambiguous, always-safe value; if your convention is "summarized data
   is fine", change `export_compliant_values` in
   `config/rule_config.json` so the scan stops flagging that state (the fix
   still defaults to the strictest option). Microsoft doesn't publish an
   authoritative list of `exportDataMode` values, so this is deliberately
   editable if a project uses a different exact string.
6. **Filter pane** — any filter that's actually *in use* (has a real
   condition applied - not just an empty card sitting in the panel with
   nothing picked) must be both **locked** and **hidden** from viewers,
   whether it's a report-level filter or set directly on one visual. A
   filter card with no value chosen is left alone — there's nothing active
   to hide. Checked and auto-fixable at both the report level (`report.json`)
   and the per-visual level (`visual.json`).
7. **Legends** — a visual's legend must not have **bold** explicitly turned
   off. The WTW theme already defaults legends to bold, so (like rule 2)
   this only catches an explicit override — if a visual doesn't set the
   property at all, it's already inheriting the correct bold default and
   isn't flagged.
8. **Data sources** — surfaces every data-source connection found in the
   report's semantic model (the `Source = ...` Power Query M steps inside
   its paired `.SemanticModel` folder's `.tmdl` files — a table's actual
   data connection, not the report's own JSON) so you can review where the
   data is really coming from — a direct SharePoint/Excel link, a specific
   SQL server, and so on. This is **detection-only**: there's no safe
   automatic fix for a data connection, so nothing here is ever
   auto-fixable — it's meant to be looked over by a person, same as the
   opt-in color findings.

All defaults were agreed with you up front. If your team's convention
differs (e.g. you also want the Options icon kept on, the approved palette
changes, or a different export-setting string counts as compliant), edit
`config/rule_config.json` and rebuild the .exe (see below) — running from
source (Option B) picks up the edit on next launch with no rebuild needed.

## Getting the app

You have two options:

### Option A - packaged .exe (recommended, no Python needed to *run* it)

Building it still needs Python once, on any machine with this folder:

1. Double-click **`build_exe.bat`**. First run installs PyInstaller and
   builds the app (a minute or two). It builds to `C:\pbip_build\dist\`
   rather than this folder - PyInstaller bundles some deeply-nested .NET
   runtime files, and if this folder's own path is already long (common
   with cloud-synced or deeply nested folders), the combined path can
   exceed Windows' 260-character limit and fail partway through with a
   confusing `FileNotFoundError`. Building to `C:\` sidesteps that.
2. Copy the resulting **`PBIP Governance Assistant.exe`** - just that one
   file - anywhere you like (Desktop, a shared drive, another machine,
   etc.) and double-click it. No Python install needed, no other files or
   folders required alongside it.
3. It self-extracts to a temp folder on every launch (that's how a
   single-file PyInstaller build works), so it opens a little slower than a
   folder-based build would - a few seconds, not more. `app.log` and the
   `backups\` folder are still created right next to wherever you put the
   `.exe`, and persist between runs as normal.
4. No console/terminal window opens - just the app itself. If the window
   ever doesn't appear, `app.log` next to the `.exe` is the only place
   startup errors get recorded, since there's no console to show them in.
5. Because everything is baked into the one file, `config/rule_config.json`
   is no longer separately editable after building - to change the icon
   list or approved palette, edit the file in this project folder and run
   `build_exe.bat` again.

Rebuild any time you change the Python code or `config/rule_config.json`
(`build_exe.bat` again).

### Option B - run from source

1. Install Python 3.10+ if you don't have it (`python --version` in a
   terminal to check).
2. Double-click **`run_windows.bat`**. The first run installs the two
   required packages for your user account (needs internet access once);
   every run after that is instant.

If you'd rather do it manually:

```
py -3 -m pip install --user -r requirements.txt
py -3 main.py
```

Either way, the app is a native window (built on the Edge WebView2 runtime,
which ships with Windows 11) — no browser tab, nothing to host.

> **Note:** `run_windows.bat` deliberately does *not* create a Python
> virtual environment. On some locked-down / corporate Windows machines,
> creating a fresh venv triggers Python's `ensurepip` step to reinstall
> `pip` from scratch, and that step can get corrupted by antivirus or
> file-sync tools mid-write (you'll see an error like `No module named
> 'pip._vendor.urllib3.packages'`). Installing straight into your existing
> user Python sidesteps that entirely.

## How to use it

1. Click **Choose PBIP Folder…** and pick the folder that contains your
   `.pbip` file (or a parent folder if you keep several PBIP projects
   together — the scanner finds every `*.Report` folder underneath).
2. Under **Checks to run**, untick anything you don't want this scan to
   look at (e.g. just want to check colors this time? untick the rest).
   All rules are on by default.
3. Click **Scan**. You'll get a summary: reports/pages/visuals scanned, and
   a count of findings for each rule you selected.
4. A **Pages** panel lists every page (plus a `(Report Theme)` entry for
   theme-level color findings) with a checkbox and a count. Uncheck any
   page you want to leave alone for now — its findings are excluded from
   "Fix Selected" but stay visible below so you can still review them.
   Click a page name to jump straight to just its findings.
   "select all pages" / "select no pages" bulk-toggle everything at once.
5. Expand a rule to see exactly which page and visual each finding is on,
   with plain-English detail (color findings show swatches, not just hex
   codes). Everything auto-selected is pre-checked; untick anything you
   don't want touched. Findings marked **"Not auto-selected"** start
   unchecked but are still fixable — check the box yourself once you've
   eyeballed it (e.g. a hardcoded color's nearest-match swatch). Each
   expanded rule also has its own **"select all in this rule"** /
   **"select none in this rule"** links — handy if you already scanned and
   now only want to fix one or two specific rules without unchecking
   everything else by hand or rescanning.
6. Click **Fix Selected**. The app backs up every file it's about to change
   into a `backups\<project name>_<timestamp>\` folder *inside the app's own
   folder* — never inside your PBIP project — then overwrites the originals
   in place. It re-scans automatically afterwards so you can confirm the
   remaining count.
7. Open the project in Power BI Desktop as usual and check it looks right.
   If anything's off, your originals are sitting untouched in that backups
   folder — just copy them back.

Rule 8 is the one exception to "everything lives in the .Report folder": it
looks in the *sibling* `.SemanticModel` folder (same project, same base
name) that PBIP always generates next to the report, and reads its `.tmdl`
files as plain text (TMDL isn't JSON). If that folder isn't found next to a
report, a warning explains why rule 8 found nothing for it rather than
staying silent.

## Formats supported

- **PBIR (enhanced report format)** — the modern PBIP layout where each
  visual is its own `visual.json` file. This is the primary, well-tested
  path.
- **Legacy PBIP** (a single `report.json` per report, visuals nested as
  stringified JSON inside it) — supported on a best-effort basis. The app
  will flag in a warning banner if a report is in this format; double-check
  those fixes before trusting them, since this older format is less
  consistently documented.

## A note on accuracy

The property names for header icons and sort direction were verified
directly against a real `visual.json` written by Power BI Desktop
(visualContainer schema 2.12.0) — not just documentation. Two important,
confirmed behaviors: Power BI never writes `"show": true` or any property
for "Focus mode" at all, since both are already the default and PBI only
persists settings that differ from default — so this tool doesn't write
them either, it only explicitly disables the *other* icons. Visual
*groups* (layout containers, distinct from real visuals) are detected and
skipped entirely, since they have no header icons of their own.

`isLockedInViewMode`/`isHiddenInViewMode` (filter pane) and `legend[].
properties.bold` were likewise confirmed directly against real project
JSON. `settings.exportDataMode`'s exact set of valid values is the one
property here Microsoft doesn't document publicly — see rule 5 above for
how that's handled conservatively and made configurable.

Still, schema details can vary across Power BI Desktop versions — **run it
on a copy or a test branch first**, confirm the diffs look right, and keep
the auto-generated backups until you're confident.

## Project layout

```
main.py                 - app entry point (pywebview window + JS bridge)
engine/
  appdirs.py             - resolves persistent app dir (backups/log) vs. bundled resource dir (ui/config, sys._MEIPASS in the onefile build)
  scanner.py             - discovers *.Report folders, pages, visuals (skips visual groups)
  rules.py                - the 4 rule checks (reads config/rule_config.json)
  fixer.py                - applies selected fixes, file by file (+ theme file)
  backup.py               - snapshots files before they're overwritten (into backups/, next to the app)
  jsonutil.py             - reads/writes PBI's boolean property encoding
  models.py               - Finding / ScanResult data structures
  service.py              - ties scan + fix together for the UI, threads the rule checklist through
ui/index.html            - the whole front-end (single file, no CDN deps)
config/rule_config.json  - editable icon list, approved palette, color object allowlist
requirements.txt
run_windows.bat          - run from source
build_exe.bat            - build a standalone .exe with PyInstaller
```
